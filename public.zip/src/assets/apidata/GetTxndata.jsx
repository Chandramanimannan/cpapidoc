import React from 'react'

function GetTxndata() {
  return (
    <div>GetTxndata</div>
  )
}

export default GetTxndata