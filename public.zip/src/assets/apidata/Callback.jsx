import React from 'react'

function Callback() {
  return (
    <div>Callback</div>
  )
}

export default Callback