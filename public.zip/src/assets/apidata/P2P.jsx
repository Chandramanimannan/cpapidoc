import React from 'react'

function P2P() {
  return (
    <div>P2P</div>
  )
}

export default P2P