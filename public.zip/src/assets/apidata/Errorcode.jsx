import React from 'react'

function Errorcode() {
  return (
    <div>Errorcode</div>
  )
}

export default Errorcode