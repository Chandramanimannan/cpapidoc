import React from 'react'

function Ifram() {
  return (
    <div>Ifram</div>
  )
}

export default Ifram