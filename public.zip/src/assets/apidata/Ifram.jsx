import React from "react";

function Ifram() {
  return (
    <div className="centpays-container">
      <h2>Iframe Payment Integration</h2>
    </div>
  );
}

export default Ifram;
