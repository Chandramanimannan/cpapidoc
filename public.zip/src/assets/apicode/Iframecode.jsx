import React, { useRef, useState } from "react";

function Iframecode() {
  return (
    <>
      <div className="codeBlock">Iframe Code</div>
    </>
  );
}

export default Iframecode;
